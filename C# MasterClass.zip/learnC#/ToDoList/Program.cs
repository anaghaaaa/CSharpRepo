﻿using System.Runtime.ConstrainedExecution;


// var todos = new List<string>(); // Use var only when type can be inferred for readability

List<string> todos = new List<string>();

Console.WriteLine("Hello!");

bool shallExit = false;
while (!shallExit)
{
    Console.WriteLine();
    Console.WriteLine("what do you want to do?");
    Console.WriteLine("[S]ee all todos");
    Console.WriteLine("[A]dd a todo");
    Console.WriteLine("[R]emove a todo");
    Console.WriteLine("[E]xit");

    var userChoice = Console.ReadLine();

    switch (userChoice)
    {
        case "E":
        case "e":
            shallExit = true;
            break;
        case "S":
        case "s":
            seeAllTodos();
            break;
        case "A":
        case "a":
            AddTodo();
            break;
        case "R":
        case "r":
            removeTodoByIndex();
            break;
        default:
            Console.WriteLine("Invalid choice");
            break;
    }
}

void AddTodo()
{
    bool isValidDescription = false;
    while (!isValidDescription)
    {
        Console.WriteLine("Enter the todo description: ");
        var description = Console.ReadLine();

        if (string.IsNullOrEmpty(description))
        {
            Console.WriteLine("The description cannot be empty.");
        }
        else if (todos.Contains(description))
        {
            Console.WriteLine("The description must be unique.");
        }
        else
        {
            isValidDescription = true;
            todos.Add(description);
        }
    }
}

void removeTodoByIndex()
{
    if (todos.Count == 0)
    {
        Console.WriteLine("No todos have been added yet.");
        return;
    }

    bool isValidIndex = false;
    while (!isValidIndex)
    {
        Console.WriteLine("Select the index of the todo you want to remove:");
        seeAllTodos();
        var userinput = Console.ReadLine();

        if (string.IsNullOrEmpty(userinput))
        {
            Console.WriteLine("Please enter a valid index.");
            continue;
        }

        int index;
        if (int.TryParse(userinput, out index) && index >= 0 && index < todos.Count)
        {
            var descriptionToRemove = todos[index];
            todos.RemoveAt(index);
            isValidIndex = true;
            Console.WriteLine($"Todo removed: {descriptionToRemove}");
        }
        else
        {
            Console.WriteLine("Please enter a valid index.");
        }
    }
}

void seeAllTodos()
{
    if (todos.Count == 0)
    {
        Console.WriteLine("No todos have been added yet.");
    }
    else
    {
        for (int i = 0; i < todos.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {todos[i]}"); // Consistent numbering starting from 1
        }
    }
}

// Use Environment.Exit for cleaner program termination
Environment.Exit(0);

