﻿var random = new Random();
var dice = new Dice (random);
var guessinggame = new GuessingGame (dice);

GameResult gameresult = guessinggame.Play();
guessinggame.PrintResult(gameresult);

Console.ReadKey();
class GuessingGame
{
    private readonly Dice _dice;
    private const int InitialTries = 3;

    public GuessingGame(Dice dice)
    {
        _dice = dice;
    }
    public GameResult Play()
    {
        var diceRollResult = _dice.Roll();
        Console.WriteLine($"Dice rolled. Guess what number was rolled in {InitialTries} tries.");
        var triesLeft = InitialTries;
        while (triesLeft > 0)
        {
            int guess = (int)consoleReader.readInteger("Enter a number:");
            if (guess == diceRollResult)
            {
                return GameResult.Victory;
            }
            Console.WriteLine("Wrong number.");
            --triesLeft;
           
        }
        return GameResult.Loss;
    }

    public void PrintResult(GameResult gameResult)
    {
        string Message = gameResult == GameResult.Victory
            ? "You win"
            : "You Lose :(";
        //if (gameResult == GameResult.Victory)
        //{
        //     Message = "You win.";
        //}
        //else
        //{
        //     Message = "You lose :(";
        //}
        Console.WriteLine(Message);
    }
}

public enum GameResult
{
    Victory,
    Loss
}
public static class consoleReader
{
    public static object readInteger(string message)
    {
        int result;
        do
        {
            Console.WriteLine($"{message}");
        }
        while (!int.TryParse(Console.ReadLine(), out result));
        return result;
    }
}
public class Dice
{
    private readonly Random _random;
    private const int noOfSides = 6;

    public Dice(Random random)
    {
        _random = random;
        
    }

    public int Roll() =>    _random.Next(1,noOfSides + 1);

    public void describe() => Console.WriteLine($"This is a dice of {noOfSides} sides");
    
}