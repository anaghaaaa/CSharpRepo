﻿using System;
using System.Text.Json;
using static GameDataParserApp;

var userInteractor = new ConsoleUserInteractor();
var app = new GameDataParserApp(userInteractor);

var logger = new Logger("log.txt");


try
{
    app.Run();
}
catch (Exception ex)
{
    Console.WriteLine("Sorry. The application has run into an unexpected error and will have to be closed.");
    logger.Log(ex);
}

Console.WriteLine("Press any key to close the application");
Console.ReadKey();

public class GameDataParserApp
{
    private readonly IUserInteractor _userInteractor;

    public GameDataParserApp(IUserInteractor userInteractor)
    {
        _userInteractor = userInteractor;
    }

    public void Run()
    {
        string filename = _userInteractor.ReadValidFilePath();
        var filecontents = File.ReadAllText(filename);
        var videoGames = DeserializeVideoGamesFrom(filename, filecontents);
        PrintGames(videoGames);
    }

    private  void PrintGames(List<VideoGame> videoGames)
    {
        if (videoGames.Count > 0)
        {
            ;
            _userInteractor.printMessage(Environment.NewLine + "The video games loaded are: ");

            foreach (var videoGame in videoGames)
            {
                _userInteractor.printMessage(videoGame.ToString());
            }

        }

        else { _userInteractor.printMessage("No games are present in input file."); }
    }

    private  List<VideoGame> DeserializeVideoGamesFrom(string filename, string filecontents)
    {
       
        try
        {
           return JsonSerializer.Deserialize<List<VideoGame>>(filecontents);
        }
        catch (JsonException ex)
        {
            
            _userInteractor.printError($"The file {filename} was not in a valid format. JSON body: ");
            _userInteractor.printError(filecontents);
            throw new JsonException($"{ex.Message} The file is : {filename}", ex);
        }

    }

    public interface IUserInteractor
    {
        string ReadValidFilePath();
        void printMessage(string message);
        void printError(string message);
    }
    public class ConsoleUserInteractor : IUserInteractor
    { 
        public void printError(string message)
        {
            var originalcolor = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Red; 
            Console.WriteLine(message);
            Console.ForegroundColor = originalcolor;
        }
        public void printMessage(string message)
        {
            Console.WriteLine(message);
        }
        public string ReadValidFilePath()
        {
            bool isFilePathValid = false;

            var filename = default(string);
            do
            {

                Console.WriteLine("Enter the name the file you want to read.");
                filename = Console.ReadLine();


                if (filename is null)
                {
                    Console.WriteLine("The filename cannot be null.");
                }
                else if (filename == String.Empty)
                {
                    Console.WriteLine("The filename cannot be empty.");
                }
                else if (!File.Exists(filename))
                {
                    Console.WriteLine("The filename does not exist.");
                }
                else
                {

                    isFilePathValid = true;
                }
            } while (!isFilePathValid);
            return filename;
        }

    }

    public class VideoGame
    {
        public string Title { get; init; }
        public int ReleaseYear { get; init; }
        public decimal Rating { get; init; }

        public override string ToString() => $"{Title}, released in {ReleaseYear} , rating: {Rating}";

    }
}