﻿public class Logger
{
    private readonly string _logfilename;

    public Logger(string logfilename)
    {
        _logfilename = logfilename;
    }

    public void Log(Exception ex)
    {
        var entry = $@"[{DateTime.Now}]
            Exception Message: {ex.Message}
            Stack Trace: {ex.StackTrace}


";
        File.AppendAllText(_logfilename, entry);
    }
}