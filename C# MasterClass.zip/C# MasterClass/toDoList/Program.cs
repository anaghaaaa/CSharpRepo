﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("Hello");
Console.WriteLine("What would you like to do?");
Console.WriteLine("[A]dd a task");
Console.WriteLine("[R]emove a task");
Console.WriteLine("[S]ee all tasks");
Console.WriteLine("[E]xit");
var userInput = Console.ReadLine();

switch (userInput)
{
    case "S":
    case "s":
        printSelectedOption("See all TODO");
        break;
    case "a":
    case "A":
        printSelectedOption("Add a TODO");
        break;

    case "R":
    case "r":
        printSelectedOption("Remove a TODO");
        break;

    case "E":
    case "e":
        printSelectedOption("Exit");
        break;
    default:
        Console.WriteLine("Invalid Choice!");
        break;

}


void printSelectedOption(string userInput)
{
    Console.WriteLine("Selected option: " + userInput);
}