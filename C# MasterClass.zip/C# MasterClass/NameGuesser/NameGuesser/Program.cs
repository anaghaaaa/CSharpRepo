﻿using System;
namespace NumberGuesser

{
    class Program
    {
        static void Main(string[] args) {

            getAppInfo();

            greetUser();

           

            while (true)
            {
                // int correctNumber = 7;
                Random random = new Random();
                int correctNumber = random.Next(1, 11);
                int guess = 0;
                Console.WriteLine("Guess a number between 0 and 10");

                while (guess != correctNumber)
                {
                    string input = Console.ReadLine();
                    if (!int.TryParse(input, out guess))
                    {
                        printColorMessage(ConsoleColor.Red, "Please use an actual number.");
                        continue;
                    }


                    guess = int.Parse(input);

                    if (guess != correctNumber)
                    {
                        printColorMessage(ConsoleColor.DarkRed, "Wrong number. Please try again.");
                        
                    }
                }
                printColorMessage(ConsoleColor.Yellow, " You are correct.");
                
                Console.WriteLine("Want to play again? (Y/N)");
                string answer = Console.ReadLine().ToUpper();
                if(answer == "Y")
                {
                    continue;
                }
                else if(answer == "N")
                {
                    return;
                }
                else
                {
                    return;
                }
            }

        }

         static void greetUser()
        {
            Console.WriteLine("What's your name?");
            string inputName = Console.ReadLine();
            Console.WriteLine("Hello, {0}. Let's play a game !", inputName);
        }

        static void getAppInfo()
        {
            string appName = "Number Guesser";
            string appVersion = "1.0.0";
            string authorName = "Anagha";

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("{0}: Version {1} by {2}", appName, appVersion, authorName);
            Console.ResetColor();
        }

        static void printColorMessage(ConsoleColor color, string message)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(message);
            Console.ResetColor();
        }
    }
}
