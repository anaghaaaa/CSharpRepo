private void button1_Click(object sender, EventArgs e)
{
    double num1 = double.Parse(textBox1.Text);
    double num2 = double.Parse(textBox2.Text);
    double result = num1 + num2;
    textBox3.Text = result.ToString();
}
