﻿using System;
using System.Numerics;

namespace CalculatorApp
{
    // Interface for calculator operations - to define behaviour implemented in inherited classes
    interface IOperation
    {
        float PerformOperation(float input1, float input2);
    }

    // Base class for common functionality - aka the operations
    abstract class MathOperation : IOperation
    {
        public abstract float PerformOperation(float input1, float input2);
    }

    //  class for addition
    class Addition : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
            return input1 + input2;
        }
    }

    //  class for subtraction
    class Subtraction : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
            return input1 - input2;
        }
    }

    //  class for multiplication

    class Multiplication : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
            return input1 * input2;
        }
    }

    //  class for division

    class Division : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
           
            
                if (input2 != 0) { return input1 / input2; }
                else {
                Console.WriteLine("Operation invalid.Cannot use division operation when denominator is zero.");
                return float.NaN; }
                
            
        }
    }

    class Calculator
    {
        public float Calculate(IOperation operation, float input1, float input2)
        {
            return operation.PerformOperation(input1, input2);
        }
    }

class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();
            //var created to decide to quit or continue using application.
            bool continueCalculating = true;

            while (continueCalculating)
            {
                Console.WriteLine("Enter the operation to be performed:");
                Console.WriteLine("Press 1 for Addition.");
                Console.WriteLine("Press 2 for Subtraction.");
                Console.WriteLine("Press 3 for Multiplication.");
                Console.WriteLine("Press 4 for Division.");
                Console.WriteLine("Press Q to quit.");

                char key = Console.ReadKey().KeyChar;
                Console.WriteLine();

                //to quit application

                if (key == 'Q' || key == 'q')
                {
                    continueCalculating = false;
                    Console.WriteLine("Exiting application.");
                }

                // to continue using calculator
                else
                {
                    Console.WriteLine("Enter the first input:");
                    float input1 = float.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the second input:");
                    float input2 = float.Parse(Console.ReadLine());

                    IOperation operation;
                    switch (key)
                    {
                        case '1':
                            operation = new Addition();
                            break;
                        case '2':
                            operation = new Subtraction();
                            break;
                        case '3':
                            operation = new Multiplication();
                            break;
                        case '4':
                            operation = new Division();
                            break;
                        default:
                            Console.WriteLine("Invalid operation. Please try again.");
                            continue;
                    }
                    //return result of operation
                    float result = calculator.Calculate(operation, input1, input2);
                    Console.WriteLine($"Result: {result}");
                }
            }
        }
    }



}
