﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Diagnostics.CodeAnalysis;


Console.WriteLine("Hello!");
Console.WriteLine("Input first number: ");
string firstText = Console.ReadLine();
int firstNumber = int.Parse(firstText);
Console.WriteLine("Input second number: ");
string  secondText = Console.ReadLine();
int secondNumber = int.Parse(secondText);


Console.WriteLine("What do you want to do? ");
Console.WriteLine("[A]dd the numbers");
Console.WriteLine("[S]ubtract the numbers");
Console.WriteLine("[M]ultiply the numbers");

var operatorChosen = Console.ReadLine();
giveOperator(operatorChosen);
int sum;
void giveOperator(string operatorChosen)
{
    
    if(operatorChosen == "A" || operatorChosen =="a")
    {
        sum = firstNumber + secondNumber;
        printFinalResult(firstNumber, secondNumber, sum, operatorChosen);
    }
    else if(operatorChosen == "S" || operatorChosen=="s") {
        sum = firstNumber - secondNumber;
        printFinalResult(firstNumber, secondNumber, sum, operatorChosen);
    }
    else if (operatorChosen == "M" || operatorChosen =="s") {
        sum = firstNumber * secondNumber;
        printFinalResult(firstNumber, secondNumber,sum,operatorChosen);
    }
    else {
        Console.WriteLine("Invalid Choice!");
    
    }
 
}


string printFinalResult(int firstNumber, int secondNumber,int sum, string operatorChosen)
{
  //  Console.WriteLine(firstNumber + " " + operatorChosen + " " + secondNumber + " = " + sum);
    Console.WriteLine($" {firstNumber} {operatorChosen} {secondNumber} = {sum} ");
}
Console.WriteLine("Press any key to close.");
Console.ReadKey();