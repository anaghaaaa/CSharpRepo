﻿using System;

namespace CalculatorApp
{ 
    //to define behavior of the classes - every class implementing it must have this behaviour.
    interface IOperation
    {
        float PerformOperation(float input1, float input2);
    }

    //to be the base class for all the classes - provides partial implementation of the method MathOperation.
    abstract class MathOperation : IOperation
    {
        public abstract float PerformOperation(float input1, float input2);
    }

    //concrete subclasses for addition, subtraction, etc.
    class Addition : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
            return input1 + input2;
        }
    }

    class Subtraction : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
            return input1 - input2;
        }
    }

    class Multiplication : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
            return input1 * input2;
        }
    }

    class Division : MathOperation
    {
        public override float PerformOperation(float input1, float input2)
        {
            if (input2 != 0)
            {
                return input1 / input2;
            }
            else
            {
                Console.WriteLine("Operation invalid. Cannot use division operation when denominator is zero.");
                return float.NaN;
            }
        }
    }

 

    class Calculator
    {
        private float _result; // private field that stores the result of the last operation

        public float Result //public method that returns the _result and sets the _result to a particular value
        {
            get { return _result; }
            set { _result = value; }
        }

        //public method which takes operation(object of IOperation iterface) and the inputs to perform calculate function on it and return result
        public float Calculate(IOperation operation, float input1, float input2)
        {
            //PerformOperation method is called here
            _result = operation.PerformOperation(input1, input2);
            return _result;
        }
    }

    //entry point for application
    class Program
    {
        static void Main(string[] args)
        {
            //instance of calculator class created
            Calculator calculator = new Calculator();
            bool continueCalculating = true;

            while (continueCalculating)
            {
                Console.WriteLine("Enter the operation to be performed:");
                Console.WriteLine("Press 1 for Addition.");
                Console.WriteLine("Press 2 for Subtraction.");
                Console.WriteLine("Press 3 for Multiplication.");
                Console.WriteLine("Press 4 for Division.");
                Console.WriteLine("Press Q to quit.");

                char key = Console.ReadKey().KeyChar;
                Console.WriteLine();

                //condition to exit application
                if (key == 'Q' || key == 'q')
                {
                    continueCalculating = false;
                    Console.WriteLine("Exiting application.");
                }

                //getting user input
                else
                {
                    Console.WriteLine("Enter the first input:");
                    float input1 = float.Parse(Console.ReadLine());

                    Console.WriteLine("Enter the second input:");
                    float input2 = float.Parse(Console.ReadLine());

                    //operation object calls Getoperation method
                    IOperation operation = GetOperation(key);
                    float result = calculator.Calculate(operation, input1, input2);
                    Console.WriteLine($"Result: {result}");

                    //to get square root of the result obtained from previous operation.
                 //   CalculateAndDisplaySquareRoot(result);

                }
            }
        }

        //method to calculate and display square root
        /*static void CalculateAndDisplaySquareRoot(float result)
        {
            double squareRoot = Math.Sqrt(result);
            Console.WriteLine($"Square root of {result} is approximately {squareRoot}");
        }
        */

        //GetOperation method returns an object implementing the IOperation interface
        static IOperation GetOperation(char key)
        {
            switch (key)
            { 
                //returns instance of the concrete class based on key
                case '1':
                    return new Addition();
                case '2':
                    return new Subtraction();
                case '3':
                    return new Multiplication();
                case '4':
                    return new Division();
                default:
                    Console.WriteLine("Invalid operation. Defaulting to addition.");
                    return new Addition();
            }
        }
    }
}
